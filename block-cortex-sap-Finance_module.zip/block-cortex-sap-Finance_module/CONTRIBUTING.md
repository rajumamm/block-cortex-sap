THIS PROJECT DOES NOT ACCEPT PATCHES OR CONTRIBUTIONS.

Please contribute to our other projects like [looker-open-source/sdk-codegen](https://github.com/looker-open-source/sdk-codegen). 

This project follows [Google's Open Source Community Guidelines](https://opensource.google/conduct/).
